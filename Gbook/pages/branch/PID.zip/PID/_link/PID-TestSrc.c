
int main(void)
{
    float Ki = 0;
    heaterInit(64.2, 96.0, 124.9, 21020, 7060, 3040, 1000, 0, &abc);
    while(1)
    {
        T = DtoTFilter(10, &abc);
        lcd_printf(LCD_LINE1, 0, LCD_LEFT, "T=%1f��", (uint16_t)(T*10));

        lcd_printf(LCD_LINE1, 0, LCD_RIGHT, "%d", (int16_t)(iTerm));
        lcd_printf(LCD_LINE2, 0, LCD_RIGHT, "%d", (int16_t)(ddTerm));

        if(100 - T <= 10)
            Ki = 0.1;

        PID_OUT = pidController(48, Ki, 1000, 100, T, 8, _PID_MODE_AUTO, _PID_DIR_FWD);
        lcd_printf(LCD_LINE2, 0, LCD_LEFT, "PID=%1f", (uint32_t)(PID_OUT*10));

        //PWM 8S���� ���Ȼ�
        for(int i=0; i<8; i++)
        {
            PORTB = 0X00;
            _delay_ms(PID_OUT);
            PORTB = 0XFF;
            _delay_ms(1000-PID_OUT);
        }

        lcd_clrScr(LCD_SCRALL);
    }

    return 0;
}

