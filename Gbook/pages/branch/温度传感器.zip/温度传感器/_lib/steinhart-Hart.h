#ifndef __ZAKI_STEINHART_HART_H__
#define __ZAKI_STEINHART_HART_H__

#include <math.h>
#include <stddef.h>


/*
*********************************************************************************************************
*
*                           STEINGHART-HART GLOBAL VARIABLES BLOCK
*
*********************************************************************************************************
*/

struct _ABC{
    float A;
    float B;
    float C;
};


/*
*********************************************************************************************************
*
*                                   FUNCTIONS DECLARATION
*
*********************************************************************************************************
*/

int steinhart_Hart_ABC(float T1, float T2, float T3, float R1, float R2, float R3, struct _ABC *abc);
float steinhart_Hart_RtoT(float R, const struct _ABC *abc);
float steinhart_Hart_TtoR(float T, const struct _ABC *abc);


#endif // __ZAKI_STEINHART_HART_H__
