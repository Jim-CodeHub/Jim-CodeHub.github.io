#include <stdio.h>
#include <math.h>

/*
*********************************************************************************************************
*
*                                             FORMULA
*
*
*        T(K) = 1/(A + Bln(R) + C[ln(R)]^3);
*        R(��) = exp(cbrt(Y-(X/2))-cbrt(Y+(X/2)));
*            X = (1/C)(A-(1/T));
*            Y = sqrt(B/(3*C)^3+(X/2)^2);
*
*            1�� = 273.15K��
*
*            Average accuracy:��0.5��
*
*
*********************************************************************************************************
*/

/*
*********************************************************************************************************
*
*                                             TESTING DATA
*
*
*                                    1.
*                                        T1 = 30��  R1 = 85100��
*                                        T2 = 45	R2 = 45300
*                                        T3 = 60	R3 = 25300
*                                    2.
*                                        T1 = 32	R1 = 80700
*                                        T2 = 60	R2 = 33300
*                                        T3 = 100	R3 = 10000
*                                    3.
*                                        T1 = 32 	R1 = 78500
*                                        T2 = 95.8	R2 = 9410
*                                        T3 = 130.4	R3 = 3495
*                                    4.
*                                        T1 = 124.9	R1 = 3040
*                                        T2 = 96.0	R2 = 7060
*                                        T3 = 64.2	R3 = 21020
*
*
*********************************************************************************************************
*/

void menu(double *T1, double *T2, double *T3, double *R1, double *R2, double *R3)
{
    puts("Input T1, T2, T3 value:");
    printf("T1 : ");
    scanf("%lf", T1);
    printf("T2 : ");
    scanf("%lf", T2);
    printf("T3 : ");
    scanf("%lf", T3);

    puts("Input R1, R2, R3 value:");
    printf("R1 : ");
    scanf("%lf", R1);
    printf("R2 : ");
    scanf("%lf", R2);
    printf("R3 : ");
    scanf("%lf", R3);

    return;
}

int test(double A, double B, double C)
{
    if(A<0 || B<0 || C<0)
    {
        puts("ERROR! The data need to be re measured!");
        return -1;
    }
    else
    {
        printf("--> A = %f, B = %f, C = %f\n", A, B, C);
    }

    return 0;
}

int main(void)
{
    int num;
    double T1, T2, T3, R1, R2, R3;
    double L1, L2, L3, Y1, Y2, Y3;
    double r2, r3, A, B, C, R, T;
    double X, Y;

    menu(&T1, &T2, &T3, &R1, &R2, &R3);

    T1 += 273.15;
    T2 += 273.15;
    T3 += 273.15;
    L1 = log(R1);
    L2 = log(R2);
    L3 = log(R3);
    Y1 = 1/T1;
    Y2 = 1/T2;
    Y3 = 1/T3;
    r2 = (Y2-Y1)/(L2-L1);
    r3 = (Y3-Y1)/(L3-L1);

    C = ((r3-r2)/(L3-L2))*(1/(L1+L2+L3));
    B = r2-C*(pow(L1, 2)+L1*L2+pow(L2, 2));
    A = Y1-L1*(B+C*pow(L1, 2));

    if(-1 == test(A, B, C))
        return -1;

    puts("Select R-T with 1 or T-R with 2");
    scanf("%d", &num);
    if(1 == num)
    {
        puts("Input R�� value(exit with a char):");
        while(scanf("%lf", &R))
        {
            T = (1/(A+B*log(R)+C*pow(log(R), 3))) - 273.15;
            printf("R-T: %lf�� <-> %lf��\n", R, T);
            puts("Input R value:");
        }
    }
    else
    {
        puts("Input T�� value(exit with a char):");
        while(scanf("%lf", &T))
        {
            X = (1/C)*(A-(1/(T+273.15)));
            Y = sqrt(pow(B/(3*C), 3)+pow((X/2), 2));
            R = exp(cbrt(Y-(X/2))-cbrt(Y+(X/2)));
            printf("T-R: %lf�� <-> %lf��\n", T, R);
            puts("Input T value:");
        }
    }

    return 0;
}
