
#include "steinhart-Hart.h"


/*
*********************************************************************************************************
*
*                                       FUNCTIONS IMPLEMENT
*
*********************************************************************************************************
*/
/**
    @fn         steinhart_Hart equation, Compute the coefficient(A, B and C) of steinhart_Hart equation
    @param[in]  Three group T-R values, which tests manually
    @param[out] abc - for function steinhart_Hart_RtoT() and steinhart_Hart_TtoR() compute.
    @return     -1 for error, 0 for normal
*/
int steinhart_Hart_ABC(float T1, float T2, float T3, float R1, float R2, float R3, struct _ABC *abc)
{
    float L1, L2, L3, Y1, Y2, Y3;
    float A, B, C;
    float r2, r3;

    T1 += 273.15;
    T2 += 273.15;
    T3 += 273.15;
    L1 = log(R1);
    L2 = log(R2);
    L3 = log(R3);
    Y1 = 1/T1;
    Y2 = 1/T2;
    Y3 = 1/T3;
    r2 = (Y2-Y1)/(L2-L1);
    r3 = (Y3-Y1)/(L3-L1);

    C = ((r3-r2)/(L3-L2))*(1/(L1+L2+L3));
    B = r2-C*(pow(L1, 2)+L1*L2+pow(L2, 2));
    A = Y1-L1*(B+C*pow(L1, 2));

    if(A<0 || B<0 || C<0)
        return -1;

    if(NULL != abc)
    {
        abc->A = A;
        abc->B = B;
        abc->C = C;
    }

    return 0;
}

/**
    @fn         steinhart_Hart equation, Compute the resistance
    @param[in]  Value of resistance R, abc - ABC values
    @param[out] None
    @return     Temperature in the value of resistance R
*/
float steinhart_Hart_RtoT(float R, const struct _ABC *abc)
{
    float A, B, C, T;

    A = abc->A;
    B = abc->B;
    C = abc->C;

    T = (1/(A+B*log(R)+C*pow(log(R), 3))) - 273.15;

    return T;
}

/**
    @fn         steinhart_Hart equation, Compute the temperature
    @param[in]  Value of temperature T, abc - ABC values
    @param[out] None
    @return     Resistance in the value of temperature T
*/
float steinhart_Hart_TtoR(float T, const struct _ABC *abc)
{
    float A, B, C;
    float X, Y, R;

    A = abc->A;
    B = abc->B;
    C = abc->C;

    X = (1/C)*(A-(1/(T+273.15)));
    Y = sqrt(pow(B/(3*C), 3)+pow((X/2), 2));

    R = exp(cbrt(Y-(X/2))-cbrt(Y+(X/2)));

    return R;
}
