#include <stdio.h>
#include <inttypes.h>
#include <math.h>

void Sigmoid(uint32_t Fset, uint32_t Fmin, uint32_t simpling, uint32_t sysClk, uint32_t timerDiv);

int main(void)
{
    uint32_t Fset, Fmin, simpling, sysClk, timerDiv;

    printf("����Ԥ��Ƶ��(Hz)Fset����Q�˳�) : ");
    while(scanf("%u", &Fset))
    {
        printf("��������Ƶ��(Hz)Fmin           : ");
        scanf("%u", &Fmin);

        printf("���������simpling             : ");
        scanf("%u", &simpling);

        printf("����ϵͳʱ��(Hz)               : ");
        scanf("%u", &sysClk);

        printf("���붨ʱ����Ƶ��               : ");
        scanf("%u", &timerDiv);

        Sigmoid(Fset, Fmin, simpling, sysClk, timerDiv);

        puts("\n===================================\n");
        printf("����Ԥ��Ƶ��(Hz)Fset����Q�˳�) : ");
    }

    return 0;
}

/**
    @fn             Step motor sigmoid curve for the array of half period and timer counter
    @param[in]      Fset - run-time freq�� Fmin - start freq
    @param[out]     none
    @note           Formula: freq = (Fset-Fmin)/(1+exp(-6*(i-simpling/2)/(simpling/2))) + Fmin
*/
void Sigmoid(uint32_t Fset, uint32_t Fmin, uint32_t simpling, uint32_t sysClk, uint32_t timerDiv)
{
    uint32_t i, tmr, timerClk, flag = 0;
    float num, freq, TC;
    float HP_arr[simpling];

    num = simpling/2.0;
    timerClk = sysClk/timerDiv;

    /** Half peroid array */
    puts("\n��������ʱ����                 : ");
    printf("\n    HP_arr = {");
    for (i = 0; i < simpling; i++)
    {
        freq = (Fset-Fmin)/(1+exp(-6*(i-num)/num)) + Fmin;

        HP_arr[i] = ((1/freq)/2) * 1000;

        if(i != simpling-1)
            printf("%d, ", (int)HP_arr[i]);
        else
            printf("%d", (int)HP_arr[i]);

        if(HP_arr[i]/(1000.0/timerClk) > 255.0)
            flag = 1;
    }
    printf("};\n");


    tmr = (flag==0)?255:65535;

    /** Timer counter array */
    puts("\n��ʱ������������ֵ����         : ");
    printf("\n     TC_arr = {");
    for (i = 0; i < simpling; i++)
    {
        TC = tmr - HP_arr[i]/(1000.0/timerClk);

        if(i != simpling-1)
            printf("%d, ", (uint32_t)TC);
        else
            printf("%d", (uint32_t)TC);
    }
    printf("};\n");

    return;
}
